﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Evade
{
    class Entity
    {
        private Brush b;
        private Point pos = new Point();

        public Entity(int size, Color c)
        {
            this.size = size;
            this.pos = new Point(0, 0);
            this.color = c;
            b = new SolidBrush(color);
        }
        public Entity(int size, Point position, Color c)
        {
            this.size = size;
            this.pos = position;
            this.color = c;
            b = new SolidBrush(color);
        }

        public void Draw(Graphics g)
        {
            g.FillRectangle(b, new Rectangle(pos,new Size(size, size)));
        }

        public int size { get; set; }
        public Point position 
        {
            get { return this.pos; }
            set { this.pos = value; } 
        }
        public Color color { get; set; }
        public Rectangle rect
        {
            get { return new Rectangle(position, new Size(size, size)); }
        }
    }
}
