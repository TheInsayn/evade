﻿namespace Evade
{
    partial class FormMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.pnlField = new System.Windows.Forms.Panel();
            this.tGame = new System.Windows.Forms.Timer(this.components);
            this.tPlayed = new System.Windows.Forms.Timer(this.components);
            this.lName = new System.Windows.Forms.Label();
            this.lPlayerName = new System.Windows.Forms.Label();
            this.lGameTime = new System.Windows.Forms.Label();
            this.lTime = new System.Windows.Forms.Label();
            this.lHighscoreTime = new System.Windows.Forms.Label();
            this.lHighscore = new System.Windows.Forms.Label();
            this.lHighscoreName = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pnlField
            // 
            this.pnlField.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnlField.BackColor = System.Drawing.Color.Black;
            this.pnlField.Location = new System.Drawing.Point(0, 0);
            this.pnlField.Name = "pnlField";
            this.pnlField.Size = new System.Drawing.Size(640, 600);
            this.pnlField.TabIndex = 0;
            this.pnlField.TabStop = true;
            this.pnlField.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlField_Paint);
            // 
            // tGame
            // 
            this.tGame.Interval = 15;
            this.tGame.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // tPlayed
            // 
            this.tPlayed.Tick += new System.EventHandler(this.tPlayed_Tick);
            // 
            // lName
            // 
            this.lName.Font = new System.Drawing.Font("Cooper Black", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lName.ForeColor = System.Drawing.Color.Black;
            this.lName.Location = new System.Drawing.Point(646, 15);
            this.lName.Name = "lName";
            this.lName.Size = new System.Drawing.Size(142, 31);
            this.lName.TabIndex = 8;
            this.lName.Text = "NAME";
            this.lName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lPlayerName
            // 
            this.lPlayerName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lPlayerName.Font = new System.Drawing.Font("Arial Black", 26.25F, System.Drawing.FontStyle.Bold);
            this.lPlayerName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(210)))));
            this.lPlayerName.Location = new System.Drawing.Point(645, 46);
            this.lPlayerName.Name = "lPlayerName";
            this.lPlayerName.Size = new System.Drawing.Size(142, 51);
            this.lPlayerName.TabIndex = 9;
            this.lPlayerName.Text = "XXX";
            this.lPlayerName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lGameTime
            // 
            this.lGameTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lGameTime.Font = new System.Drawing.Font("Arial Black", 26.25F, System.Drawing.FontStyle.Bold);
            this.lGameTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(210)))));
            this.lGameTime.Location = new System.Drawing.Point(647, 193);
            this.lGameTime.Name = "lGameTime";
            this.lGameTime.Size = new System.Drawing.Size(142, 51);
            this.lGameTime.TabIndex = 11;
            this.lGameTime.Text = "00,0";
            this.lGameTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lTime
            // 
            this.lTime.Font = new System.Drawing.Font("Cooper Black", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lTime.ForeColor = System.Drawing.Color.Black;
            this.lTime.Location = new System.Drawing.Point(648, 162);
            this.lTime.Name = "lTime";
            this.lTime.Size = new System.Drawing.Size(142, 31);
            this.lTime.TabIndex = 10;
            this.lTime.Text = "TIME";
            this.lTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lHighscoreTime
            // 
            this.lHighscoreTime.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lHighscoreTime.Font = new System.Drawing.Font("Arial Black", 26.25F, System.Drawing.FontStyle.Bold);
            this.lHighscoreTime.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(200)))), ((int)(((byte)(210)))));
            this.lHighscoreTime.Location = new System.Drawing.Point(649, 489);
            this.lHighscoreTime.Name = "lHighscoreTime";
            this.lHighscoreTime.Size = new System.Drawing.Size(142, 51);
            this.lHighscoreTime.TabIndex = 13;
            this.lHighscoreTime.Text = "12,3";
            this.lHighscoreTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lHighscore
            // 
            this.lHighscore.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lHighscore.ForeColor = System.Drawing.Color.Black;
            this.lHighscore.Location = new System.Drawing.Point(649, 458);
            this.lHighscore.Name = "lHighscore";
            this.lHighscore.Size = new System.Drawing.Size(142, 31);
            this.lHighscore.TabIndex = 12;
            this.lHighscore.Text = "HIGHSCORE";
            this.lHighscore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lHighscoreName
            // 
            this.lHighscoreName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lHighscoreName.Font = new System.Drawing.Font("Arial Black", 26.25F, System.Drawing.FontStyle.Bold);
            this.lHighscoreName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(215)))), ((int)(((byte)(215)))));
            this.lHighscoreName.Location = new System.Drawing.Point(648, 540);
            this.lHighscoreName.Name = "lHighscoreName";
            this.lHighscoreName.Size = new System.Drawing.Size(142, 51);
            this.lHighscoreName.TabIndex = 14;
            this.lHighscoreName.Text = "YYY";
            this.lHighscoreName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.lHighscoreName);
            this.Controls.Add(this.lHighscoreTime);
            this.Controls.Add(this.lHighscore);
            this.Controls.Add(this.lGameTime);
            this.Controls.Add(this.lTime);
            this.Controls.Add(this.lPlayerName);
            this.Controls.Add(this.lName);
            this.Controls.Add(this.pnlField);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMain";
            this.Text = "Evade v0.2.5";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormMain_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FormMain_KeyUp);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlField;
        private System.Windows.Forms.Timer tGame;
        private System.Windows.Forms.Timer tPlayed;
        private System.Windows.Forms.Label lName;
        private System.Windows.Forms.Label lPlayerName;
        private System.Windows.Forms.Label lGameTime;
        private System.Windows.Forms.Label lTime;
        private System.Windows.Forms.Label lHighscoreTime;
        private System.Windows.Forms.Label lHighscore;
        private System.Windows.Forms.Label lHighscoreName;
    }
}

