﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evade
{
    public partial class FormMain : Form
    {
        private const int PLAYERSIZE = 30;
        private const int PLAYERMOVESPEED = 8;

        private const int BLOCKMINSIZE = 30;
        private const int BLOCKMAXSIZE = 60;
        private const int BLOCKMINSPEED = 5;
        private const int BLOCKMAXSPEED = 8;
        
        private Color PLAYERCOLOR = Color.Yellow;
        private Color BLOCKCOLOR = Color.Red;

        private Player player;
        private List<Block> blocks = new List<Block>();
        private Graphics g;
        private float gamespeed = 1;
        private int direction = 0;
        private float count = 0;
        private float timePlayed = -1;
        Random rand = new Random();

        public FormMain()
        {
            InitializeComponent();
            //get player name
            FormWelcome fw = new FormWelcome();
            if(fw.ShowDialog() == DialogResult.OK)
                lPlayerName.Text = fw.playerName;

            g = pnlField.CreateGraphics();
            player = new Player(PLAYERSIZE, new Point(pnlField.Width/2 - PLAYERSIZE/2, pnlField.Height - PLAYERSIZE), PLAYERCOLOR);
            //get highscore
            string name = FileManager.ReadAttribute("name");
            float time = float.Parse(FileManager.ReadAttribute("time"));
            lHighscoreName.Text = name;
            lHighscoreTime.Text = time.ToString();
            tGame.Start();
            tPlayed.Start();
        }

        private void pnlField_Paint(object sender, PaintEventArgs e)
        {
            player.Draw(g);
            foreach(Block b in blocks){
                b.Draw(g);
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            UpdatePlayerPos();
            if(timePlayed >= 0) { //countdown to game-start
                UpdateBlockPos();
                count += gamespeed;
                if(count >= 15) { //#magicnumber
                    count = 0;
                    CreateBlock();
                }
            }
            pnlField.Invalidate();
        }

        private void UpdatePlayerPos()
        {
            int movement = 0;

            switch(direction) {
                case -1:
                    movement = -PLAYERMOVESPEED;
                    break;
                case 1:
                    movement = PLAYERMOVESPEED;
                    break;
                default:
                    break;
            }
            if(movement != 0) {
                Point pos = player.position;
                Point newPos = new Point(pos.X + movement, pos.Y);
                if(newPos.X >= 0 && newPos.X + PLAYERSIZE <= pnlField.Width)
                    player.position = newPos;
            }
        }

        private void UpdateBlockPos()
        {
            Point pos;
            foreach (Block b in blocks){
                pos = b.position;
                pos.Y += (int)(b.moveSpeed * gamespeed);
                b.position = pos;
                if(b.rect.IntersectsWith(player.rect))
                    KillPlayer();
                if(pos.Y + b.size >= pnlField.Height)
                    BeginInvoke((Action)(() => blocks.Remove(b)));
            }
        }

        private void KillPlayer()
        {
            tGame.Stop();
            tPlayed.Stop();
            CheckHighscore();
            EndGame();
        }

        private void CreateBlock()
        {
            int size = rand.Next(BLOCKMINSIZE, BLOCKMAXSIZE);
            int pos = rand.Next(pnlField.Width-size);
            int speed = rand.Next(BLOCKMINSPEED, BLOCKMAXSPEED+1);
            blocks.Add(new Block(size, new Point(pos, -size), BLOCKCOLOR, speed));
        }

        private void CheckHighscore()
        {
            //get previous highscore
            string name = lHighscoreName.Text;
            float score = float.Parse(lHighscoreTime.Text);
            if(timePlayed >= score) { //highscore beaten - replace it
                string newName = lPlayerName.Text;
                string newTime = lGameTime.Text;
                FileManager.WriteAttribute("name", newName);
                FileManager.WriteAttribute("time",newTime);
                lHighscoreName.Text = newName;
                lHighscoreTime.Text = newTime;
            }
            
        }

        private void EndGame()
        {
            FormEnd fe = new FormEnd(lPlayerName.Text, lGameTime.Text, lHighscoreName.Text, lHighscoreTime.Text);
            if(fe.ShowDialog() == DialogResult.Retry)
                RestartGame();
            else
                Application.Exit();
        }

        private void RestartGame()
        {
            //reset game variables
            blocks = new List<Block>();
            gamespeed = 1;
            direction = 0;
            count = 0;
            timePlayed = -1;
            player = new Player(PLAYERSIZE, new Point(pnlField.Width / 2 - PLAYERSIZE / 2, pnlField.Height - PLAYERSIZE), PLAYERCOLOR);
            //get highscore
            string name = FileManager.ReadAttribute("name");
            float time = float.Parse(FileManager.ReadAttribute("time"));
            lHighscoreName.Text = name;
            lHighscoreTime.Text = time.ToString();
            tGame.Start();
            tPlayed.Start();
        }

        private void FormMain_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Left)
                direction = -1;
            else if(e.KeyCode == Keys.Right)
                direction = 1;
        }

        private void FormMain_KeyUp(object sender, KeyEventArgs e)
        {
            if(direction == -1 && e.KeyCode == Keys.Left ||
                direction == 1 && e.KeyCode == Keys.Right) 
                direction = 0;

        }

        private void tPlayed_Tick(object sender, EventArgs e)
        {
            gamespeed = 1 + ((int)timePlayed/10)/5.0F; //#magicnumber
            timePlayed += 0.1F;
            lGameTime.Text = timePlayed.ToString("0.0");
        }
    }
}
