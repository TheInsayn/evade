﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evade
{
    public partial class FormWelcome : Form
    {
        public FormWelcome()
        {
            InitializeComponent();
            this.KeyPreview = true;
        }

        public string playerName
        {
            get {
                string text = mtxtName.Text;
                StringBuilder sb = new StringBuilder(text);
                sb.Replace(" ", "");
                text = sb.ToString();
                return text;
            }
        }

        private void FormWelcome_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Return)
                this.DialogResult = DialogResult.OK;
        }
    }
}
