﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Evade
{
    class Player: Entity
    {
        public Player(int size, Color c) : base(size, c) { }
        public Player(int size, Point position, Color c) : base(size, position, c) { }
    }
}
