﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Evade
{
    class Block : Entity
    {
        //public Block(int size, Color c) : base(size, c) { }
        public Block(int size, Point position, Color c, int speed) : base(size, position, c)
        {
            this.moveSpeed = speed;
        }

        public int moveSpeed { get; set; }
    }
}
