﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evade
{
    public partial class FormEnd : Form
    {
        public FormEnd(string playerName, string playerTime, string highscoreName, string highscoreTime)
        {
            InitializeComponent();
            this.KeyPreview = true;
            if(float.Parse(playerTime) >= float.Parse(highscoreTime)) {
                lScore.Text = String.Format(
                    "Excellent {0}! You have beaten the highscore by surviving for {1} seconds.",
                    playerName,
                    playerTime);
            }
            else {
                lScore.Text = String.Format(
                    "Well done, {0}. You have survived for {1} seconds.\nThe highscore is by {2} with {3} seconds.",
                    playerName,
                    playerTime,
                    highscoreName,
                    highscoreTime);
            }
        }

        private void FormEnd_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode == Keys.Return)
                this.DialogResult = DialogResult.Retry;
            else if(e.KeyCode == Keys.Delete)
                ResetScore();
            else if(e.KeyCode == Keys.Escape)
                Application.Exit();
        }

        private void ResetScore()
        {
            FileManager.WriteAttribute("name", "XXX");
            FileManager.WriteAttribute("time", "00,0");
        }
    }
}
